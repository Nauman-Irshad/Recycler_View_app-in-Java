package com.example.cp5;

public class Contact {

    private String name;


    public Contact(String name) {
        this.name = name;
    }


    public String getName() {
        return name;
    }


    public void setName(String name) {
        this.name = name;
    }
}
